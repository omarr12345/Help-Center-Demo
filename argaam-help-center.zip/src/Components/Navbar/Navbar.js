import React from "react";
import "./navbar.css";

function Navbar() {
  return (
    <div className="header">
      <img
        src={require("../../assets/argaam-plus-en.png")}
        className="argaam-icon"
      />
    </div>
  );
}

export default Navbar;
