import React from "react";
import "./searchbar.css";
function SearchBar() {
  return (
    <div className="search-bar container my-3">
      <h2 className="text-center">Help Center</h2>
      <form className="search-form my-3">
        <input className="form-control w-75 f-w-bold" type="text" />
        <img
          src={require("../../assets/search-btn.png")}
          className="search-img"
        />
      </form>
    </div>
  );
}

export default SearchBar;
