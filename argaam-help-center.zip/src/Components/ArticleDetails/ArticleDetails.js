import React from "react";
import "./ArticleDetails.css";
import { useState, useRef, useEffect } from "react";
import { useParams } from "react-router";
import allData from "../../Backend/Data.json";

function ArticleDetails() {
  let { articleId } = useParams();
  const article = allData.filter((v) => {
    return v.id == articleId;
  });

  return (
    <div className="article-details container">
      {article.map((art) => {
        return <div>{articleId}</div>;
      })}
    </div>
  );
}

export default ArticleDetails;
