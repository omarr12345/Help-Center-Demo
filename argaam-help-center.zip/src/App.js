import { Route } from "react-router";
import Articles from "./Components/Articles/Articles";
import Navbar from "./Components/Navbar/Navbar";
import RecentSearches from "./Components/RecentSearches/RecentSearches";
import SearchBar from "./Components/SearchBar/SearchBar";
import { Router, Routes } from "react-router";
import ArticleDetails from "./Components/ArticleDetails/ArticleDetails";

function App() {
  return (
    <div className="App">
      <Navbar />
      <SearchBar />
      <RecentSearches />
      <Routes>
        <Route path="/omar" element={<ArticleDetails />} />
        <Route path="/" element={<Articles />} />
        <Route path="/article/:id" element={<ArticleDetails />} />
      </Routes>
    </div>
  );
}

export default App;
